use utf8;
use strict;

package XML::Pastor::Element;
use base qw(XML::Pastor::ComplexType);

XML::Pastor::Element->mk_classdata('XmlSchemaElement');


1;

__END__



